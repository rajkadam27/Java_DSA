public class for_loop{
    
    public static void main(String args []){

for(int a=1 ; a<10; a++){
    
     System.out.println("raj");
        
}
        
    System.out.println("raj kadam");
    }
}