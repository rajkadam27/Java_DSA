import java.util.*;

public class TreehMap_map{

    public static void main(String args[]){

        TreeMap<String,Integer> tm = new TreeMap<>();  

        tm.put("india",100);
        tm.put("China",150);
        tm.put("USA",50);

        System.out.println(tm);

        // System.out.println(hm.get("india"));

        // System.out.println(hm.containsKey("india"));
        // System.out.println(hm.containsKey("japan"));

        // System.out.println(hm.remove("China"));
        // System.out.println(hm);

        // System.out.println(hm.size());

        // // hm.clear();
        // // System.out.println(hm);
        // // System.out.println(hm.isEmpty());

        // //iterator

        // Set<String> keys = hm.keySet();
        // System.out.println(keys); 

        // for(String k : keys){
        //     System.out.println("key " +k+ " ,value " +hm.get(k)); 
        // }

        
        }
        
}


