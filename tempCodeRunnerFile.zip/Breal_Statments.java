public class Breal_Statments{
    
    public static void main(String args []){

for(int a=1 ; a<10; a++){
    if(a==3){
       break;
    }
     System.out.println(a);
        
}
    System.out.println("raj kadam");
    }
}