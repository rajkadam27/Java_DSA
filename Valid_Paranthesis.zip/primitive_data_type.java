public class primitive_data_type{
    
    public static void main(String args []){

        byte b = 8;
        System.out.println(b);

        char ch  = 'c';
        System.out.println(ch);

        float a = 8;
        System.out.println(a);

        int d = 7;
        System.out.println(d);

        short e = 8;
        System.out.println(e);

        boolean var = true;
        System.out.println(var);

        //long
        //double
    }
}