class Solution {
    public void findMedianSortedArrays(int[] nums1, int[] nums2) {
        int[] c = new int []{nums1,nums2};

        c= nums1 + nums2;
        system.out.println(c);
        
        Arrays.sort(c) ;  // sort the array

        for(int i=0 ; i<=c.length() ; i++){
             int si =0;
             int end = c[i]-1;

             float mid = (si+end)/2;
             system.out.println(mid);
        }
    }
    public static void main(String[] args){
        Solution s = new Solution();
        s.findMedianSortedArrays(new int[]{1,3}, new int[]{2});
    }
}